﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LevelSelector : MonoBehaviour
{
    public SceneFader Fader;

    public Button[] LevelButtons;

    private void Start()
    {
        int levelReach = PlayerPrefs.GetInt("levelReach", 1);

        for (int i = 0; i < LevelButtons.Length; i++)
        {
            if (i + 1 > levelReach)
            {
                LevelButtons[i].interactable = false;
                LevelButtons[i].image.color = new Color(255f, 255f, 255f, 75f);

            }
        }
    }
    public void Select(string LevelName)
    {
        Fader.FadeTo(LevelName);
    }
}
