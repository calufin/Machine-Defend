﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Game_Manager : MonoBehaviour
{
    public static bool GameisOver;

    public GameObject gameOverUI;

    public string nextLevel = "Level2";
    public int LevelUnlock = 2;

    public SceneFader Fader;

    // Start is called before the first frame update
    void Start()
    {
        GameisOver = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (GameisOver)
        {
            return;
        }

        if (Input.GetKeyDown("e"))
        {
            EndGame();
        }
        if (PlayerStats.Lives <= 0)
        {
            EndGame();
        }
    }

    void EndGame()
    {
        GameisOver = true;
        gameOverUI.SetActive(true);

    }

    public void WinLevel()
    {
        Debug.Log("Won1!!!!");
        PlayerPrefs.SetInt("levelReach", LevelUnlock);
        Fader.FadeTo(nextLevel);
    }
}
