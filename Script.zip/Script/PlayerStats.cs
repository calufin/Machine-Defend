﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerStats : MonoBehaviour
{
    public static int Money;
    public int StartMoney = 50;

    public static int Lives;
    public int startLives = 20;

    private float countDown = 5f;

    public static int Rounds;

    private void Start()
    {
        Money = StartMoney;
        Lives = startLives;
        Rounds = 0;
    }

    private void Update()
    {
        if (countDown <= 0f)
        {

            Money = Money + 1;
            countDown = 1f;
        }
        countDown -= Time.deltaTime;
        countDown = Mathf.Clamp(countDown, 0f, Mathf.Infinity);
    }
}
