﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class WaveSpawner : MonoBehaviour
{
    public static int EnemiesAlive = 0;
    public Wave[] waves;
    public Transform spawnPoint;
    public float TimeBetweenWave = 5f;
    private float countDown = 2f;
    private int waveNumber = 0;
    public Text waveTimer;
    public Text WaveCounter;
    public Game_Manager gameManager;
    void Update()
    {
        WaveCounter.text = string.Format("Wave # " + waveNumber);
        if (EnemiesAlive > 0)
        {
            return;
        }
        if (countDown <= 0f)
        {
            StartCoroutine(SpawnWave());
            countDown = TimeBetweenWave;
            return;
        }
        countDown -= Time.deltaTime;
        countDown = Mathf.Clamp(countDown, 0f, Mathf.Infinity);
        waveTimer.text = string.Format("Timer: "+"{0:00.00}", countDown);
        
    }
    IEnumerator SpawnWave()
    {
        PlayerStats.Rounds++;

        Wave wave = waves[waveNumber];

        EnemiesAlive = wave.count;
        for (int i = 0; i < wave.count; i++)
        {
            SpawnEnemy(wave.enemy);
            yield return new WaitForSeconds(1f / wave.rate);
        }
        Enemy.GetMoreHealth();

        if (waveNumber > waves.Length)
        {
            gameManager.WinLevel();
            Debug.Log("LEVEL Won!!!");
            this.enabled = false;
        }
        waveNumber++;
        
    }
    void SpawnEnemy(GameObject enemy)
    {
        Instantiate(enemy, spawnPoint.position, spawnPoint.rotation);
    }
}
