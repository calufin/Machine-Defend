﻿using UnityEngine;
using UnityEngine.EventSystems;
using System.Collections;
using System.Collections.Generic;

public class Nodes : MonoBehaviour
{
    public Color hoveColor;
    public Color NotEnoughMoneyCol;
    private Renderer rend;
    private Color StartColor;
    public Vector3 positionOffset;
    BuildManager buildmanager;


    [Header("Optional")]
    public GameObject turret;
    public TurretBlueprint turretBlueprint;
    public bool isUpgraded = false;


    // Start is called before the first frame update
    void Start()
    {
        rend = GetComponent<Renderer>();
        StartColor = rend.material.color;
        buildmanager = BuildManager.instance;
    }

    public Vector3 GetBuildPosition()
    {
        return transform.position + positionOffset;
    }
    private void OnMouseDown()
    {
        if (EventSystem.current.IsPointerOverGameObject())
        {
            return;
        }
        
        if (turret != null)
        {
            buildmanager.SelectNode(this);
            return;
        }
        //Build a torret
        if (!buildmanager.CanBuild)
        {
            return;
        }

        BuildTurret(buildmanager.GetTurretToBuild());

    }
    void BuildTurret (TurretBlueprint blueprint)
    {
        if (PlayerStats.Money < blueprint.cost)
        {
            Debug.Log("Not Enought to buy");
            return;
        }

        PlayerStats.Money -= blueprint.cost;

        GameObject _turret = (GameObject)Instantiate(blueprint.prefab, GetBuildPosition(), Quaternion.identity);
        turret = _turret;

        turretBlueprint = blueprint;

        Debug.Log("Turret build!");
    }

    public void UpgradeTorret()
    {
        if (PlayerStats.Money < turretBlueprint.Upgradecost)
        {
            Debug.Log("Not Enought to Upgrade");
            return;
        }

        PlayerStats.Money -= turretBlueprint.Upgradecost;

        Destroy(turret);

        GameObject _turret = (GameObject)Instantiate(turretBlueprint.upgradedPrefab, GetBuildPosition(), Quaternion.identity);
        turret = _turret;

        isUpgraded = true;

        Debug.Log("Turret Upgraded!");
    }

    public void SellTurret()
    {
        PlayerStats.Money += turretBlueprint.GetSellAmount();

        Destroy(turret);
        turretBlueprint = null;
    }

    void OnMouseEnter()
    {
        if (EventSystem.current.IsPointerOverGameObject())
        {
            return;
        }
        if (!buildmanager.CanBuild)
        {
            return;
        }
        if (buildmanager.HasMoney)
        {
            rend.material.color = hoveColor;
        }
        else
        {
            rend.material.color = NotEnoughMoneyCol;
        }

        
    }

    void OnMouseExit()
    {
        rend.material.color = StartColor;
    }
}
