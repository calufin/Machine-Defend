﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Enemy : MonoBehaviour
{
    public float startSpeed = 6f;
    [HideInInspector]
    public float speed;

    public float startHealth = 100;
    public float health;
    public static float MoreHealth = 0;
    public int coin = 5;
    public Image healthBar;

    public GameObject deathEffect;
    // Start is called before the first frame update

    private void Start()
    {
        speed = startSpeed;
        health = startHealth + MoreHealth;
        
    }

    public static void GetMoreHealth()
    {
        MoreHealth += 15;
    }
    
    public void TakeDamage(int amount)
    {
        health -= amount;

        healthBar.fillAmount = health / (startHealth + MoreHealth);

        if (health <= 0)
        {
            Die();
        }
    }

    public void Slow(float amount)
    {
        speed = startSpeed * (1f - amount);
    }

    void Die()
    {
        PlayerStats.Money += coin;

        GameObject effect =(GameObject)Instantiate(deathEffect, transform.position, Quaternion.identity);
        Destroy(effect, 2f);
        WaveSpawner.EnemiesAlive--;
        Destroy(gameObject);
    }

    

    // Update is called once per frame

}
