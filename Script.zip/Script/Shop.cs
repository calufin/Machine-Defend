﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shop : MonoBehaviour
{
    public TurretBlueprint standardTurret;
    public TurretBlueprint anotherTurret;
    BuildManager buildManager;

    private void Start()
    {
        buildManager = BuildManager.instance;
    }
    public void SelectNormalTurret()
    {
        Debug.Log("Purchase normal");
        buildManager.SelectTurretToBuild(standardTurret);
    }
    public void SelectAnotherTurret()
    {
        Debug.Log("Purchase another");
        buildManager.SelectTurretToBuild(anotherTurret);

    }
}
